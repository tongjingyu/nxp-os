#ifndef _LOCKCODE_H_
#define _LOCKCODE_H_
#include<include.h>

extern const uint16 CodeTab[];
BOOL AppLicense(void);

#endif
