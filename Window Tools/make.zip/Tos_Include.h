#ifndef _TOS_INCLUDE_H_
#define _TOS_INCLUDE_H_

#include <Include.h>
#include <Tos.h>
#include <Tos_Timer.h>
#include <Tos_Timed.h>
#include <Tos_device.h>
#include <LockCode.h>
#include <Tos_Mema.h>

#endif
